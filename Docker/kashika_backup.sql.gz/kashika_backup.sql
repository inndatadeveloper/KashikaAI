--
-- PostgreSQL database dump
--

\restrict Vy7a4tpt31ZN35ehoau0VBMCWySl8faWBuFRNIox1P1v2Bw3qv1hueqg0qKPeoA

-- Dumped from database version 16.11
-- Dumped by pg_dump version 16.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: mentiontype; Type: TYPE; Schema: public; Owner: kashika
--

CREATE TYPE public.mentiontype AS ENUM (
    'FILE',
    'MEMORY',
    'DATA_SOURCE'
);


ALTER TYPE public.mentiontype OWNER TO kashika;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: agent_executions; Type: TABLE; Schema: public; Owner: kashika
--

CREATE TABLE public.agent_executions (
    completion_id character varying(36) NOT NULL,
    organization_id character varying(36),
    user_id character varying(36),
    report_id character varying(36),
    status character varying NOT NULL,
    started_at timestamp without time zone,
    completed_at timestamp without time zone,
    total_duration_ms double precision,
    first_token_ms double precision,
    thinking_ms double precision,
    latest_seq integer NOT NULL,
    token_usage_json json,
    error_json json,
    config_json json,
    id character varying(36) NOT NULL,
    bow_version character varying,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone
);


ALTER TABLE public.agent_executions OWNER TO kashika;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: kashika
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO kashika;

--
-- Name: apscheduler_jobs; Type: TABLE; Schema: public; Owner: kashika
--

CREATE TABLE public.apscheduler_jobs (
    id character varying(191) NOT NULL,
    next_run_time double precision,
    job_state bytea NOT NULL
);


ALTER TABLE public.apscheduler_jobs OWNER TO kashika;

--
-- Name: completion_blocks; Type: TABLE; Schema: public; Owner: kashika
--

CREATE TABLE public.completion_blocks (
    completion_id character varying(36) NOT NULL,
    agent_execution_id character varying(36),
    source_type character varying NOT NULL,
    plan_decision_id character varying(36),
    tool_execution_id character varying(36),
    block_index integer NOT NULL,
    loop_index integer,
    title character varying NOT NULL,
    status character varying NOT NULL,
    icon character varying,
    content character varying,
    reasoning character varying,
    started_at timestamp without time zone,
    completed_at timestamp without time zone,
    id character varying(36) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone
);


ALTER TABLE public.completion_blocks OWNER TO kashika;

--
-- Name: completion_feedbacks; Type: TABLE; Schema: public; Owner: kashika
--

CREATE TABLE public.completion_feedbacks (
    user_id character varying(36),
    completion_id character varying(36) NOT NULL,
    organization_id character varying(36) NOT NULL,
    direction integer NOT NULL,
    message text,
    reviewed_at timestamp without time zone,
    reviewed_by character varying(36),
    id character varying(36) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone
);


ALTER TABLE public.completion_feedbacks OWNER TO kashika;

--
-- Name: completions; Type: TABLE; Schema: public; Owner: kashika
--

CREATE TABLE public.completions (
    id character varying(36) NOT NULL,
    prompt json NOT NULL,
    completion json NOT NULL,
    status character varying NOT NULL,
    model character varying NOT NULL,
    turn_index integer NOT NULL,
    parent_id character varying(36),
    message_type character varying NOT NULL,
    role character varying NOT NULL,
    report_id character varying(36) NOT NULL,
    widget_id character varying(36),
    step_id character varying(36),
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone,
    user_id character varying(36),
    main_router character varying NOT NULL,
    feedback_score integer DEFAULT 0 NOT NULL,
    sigkill timestamp without time zone,
    external_platform character varying,
    external_message_id character varying,
    external_user_id character varying,
    instructions_effectiveness integer,
    context_effectiveness integer,
    response_score integer
);


ALTER TABLE public.completions OWNER TO kashika;

--
-- Name: context_snapshots; Type: TABLE; Schema: public; Owner: kashika
--

CREATE TABLE public.context_snapshots (
    agent_execution_id character varying(36) NOT NULL,
    kind character varying NOT NULL,
    context_view_json json NOT NULL,
    prompt_text character varying,
    prompt_tokens character varying,
    hash character varying,
    id character varying(36) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone
);


ALTER TABLE public.context_snapshots OWNER TO kashika;

--
-- Name: dashboard_layout_versions; Type: TABLE; Schema: public; Owner: kashika
--

CREATE TABLE public.dashboard_layout_versions (
    name character varying NOT NULL,
    version integer NOT NULL,
    is_active boolean NOT NULL,
    theme_name character varying,
    theme_overrides json,
    blocks json NOT NULL,
    report_id character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone
);


ALTER TABLE public.dashboard_layout_versions OWNER TO kashika;

--
-- Name: data_source_memberships; Type: TABLE; Schema: public; Owner: kashika
--

CREATE TABLE public.data_source_memberships (
    data_source_id character varying(36) NOT NULL,
    principal_type character varying NOT NULL,
    principal_id character varying(36) NOT NULL,
    config json,
    id character varying(36) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone
);


ALTER TABLE public.data_source_memberships OWNER TO kashika;

--
-- Name: data_sources; Type: TABLE; Schema: public; Owner: kashika
--

CREATE TABLE public.data_sources (
    name character varying NOT NULL,
    type character varying NOT NULL,
    config json NOT NULL,
    last_synced_at timestamp without time zone,
    is_active boolean NOT NULL,
    organization_id character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone,
    context text,
    description text,
    summary text,
    conversation_starters json,
    credentials text,
    is_public boolean DEFAULT true NOT NULL,
    owner_user_id character varying(36),
    use_llm_sync boolean DEFAULT false NOT NULL,
    auth_policy character varying DEFAULT 'system_only'::character varying NOT NULL,
    allowed_user_auth_modes json
);


ALTER TABLE public.data_sources OWNER TO kashika;

--
-- Name: datasource_tables; Type: TABLE; Schema: public; Owner: kashika
--

CREATE TABLE public.datasource_tables (
    name character varying NOT NULL,
    columns json NOT NULL,
    no_rows integer NOT NULL,
    datasource_id character varying(36) NOT NULL,
    pks json NOT NULL,
    fks json NOT NULL,
    is_active boolean NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone,
    centrality_score double precision,
    richness double precision,
    degree_in integer,
    degree_out integer,
    entity_like boolean,
    metrics_computed_at timestamp without time zone,
    metadata_json json
);


ALTER TABLE public.datasource_tables OWNER TO kashika;

--
-- Name: entities; Type: TABLE; Schema: public; Owner: kashika
--

CREATE TABLE public.entities (
    organization_id character varying(36) NOT NULL,
    owner_id character varying(36) NOT NULL,
    type character varying NOT NULL,
    title character varying NOT NULL,
    slug character varying NOT NULL,
    description text,
    tags json,
    code text NOT NULL,
    data json,
    original_data_model json,
    view json,
    status character varying NOT NULL,
    published_at timestamp without time zone,
    pinned boolean NOT NULL,
    last_refreshed_at timestamp without time zone,
    auto_refresh_enabled boolean NOT NULL,
    auto_refresh_interval integer,
    auto_refresh_interval_unit character varying,
    private_status character varying(50),
    global_status character varying(50),
    reviewed_by_user_id character varying(36),
    source_step_id character varying(36),
    trigger_reason character varying(255),
    ai_source character varying(50),
    id character varying(36) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone
);


ALTER TABLE public.entities OWNER TO kashika;

--
-- Name: entity_data_source_association; Type: TABLE; Schema: public; Owner: kashika
--

CREATE TABLE public.entity_data_source_association (
    entity_id character varying(36) NOT NULL,
    data_source_id character varying(36) NOT NULL
);


ALTER TABLE public.entity_data_source_association OWNER TO kashika;

--
-- Name: external_platforms; Type: TABLE; Schema: public; Owner: kashika
--

CREATE TABLE public.external_platforms (
    organization_id character varying NOT NULL,
    platform_type character varying NOT NULL,
    platform_config json NOT NULL,
    credentials text,
    is_active boolean NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone
);


ALTER TABLE public.external_platforms OWNER TO kashika;

--
-- Name: external_user_mappings; Type: TABLE; Schema: public; Owner: kashika
--

CREATE TABLE public.external_user_mappings (
    organization_id character varying NOT NULL,
    platform_type character varying NOT NULL,
    platform_id character varying NOT NULL,
    external_user_id character varying NOT NULL,
    external_email character varying,
    external_name character varying,
    app_user_id character varying(36),
    is_verified boolean NOT NULL,
    verification_token character varying,
    verification_expires_at timestamp without time zone,
    last_verified_at timestamp without time zone,
    id character varying(36) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone
);


ALTER TABLE public.external_user_mappings OWNER TO kashika;

--
-- Name: file_tags; Type: TABLE; Schema: public; Owner: kashika
--

CREATE TABLE public.file_tags (
    key character varying NOT NULL,
    value character varying NOT NULL,
    file_id character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone
);


ALTER TABLE public.file_tags OWNER TO kashika;

--
-- Name: files; Type: TABLE; Schema: public; Owner: kashika
--

CREATE TABLE public.files (
    filename character varying,
    path character varying,
    content_type character varying,
    id character varying(36) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone,
    user_id character varying(36) NOT NULL,
    organization_id character varying(36) NOT NULL
);


ALTER TABLE public.files OWNER TO kashika;

--
-- Name: git_repositories; Type: TABLE; Schema: public; Owner: kashika
--

CREATE TABLE public.git_repositories (
    provider character varying NOT NULL,
    repo_url character varying NOT NULL,
    last_indexed_at timestamp without time zone,
    ssh_key text,
    branch character varying,
    is_active boolean NOT NULL,
    status character varying,
    user_id character varying(36) NOT NULL,
    data_source_id character varying(36),
    organization_id character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone
);


ALTER TABLE public.git_repositories OWNER TO kashika;

--
-- Name: instruction_data_source_association; Type: TABLE; Schema: public; Owner: kashika
--

CREATE TABLE public.instruction_data_source_association (
    instruction_id character varying(36) NOT NULL,
    data_source_id character varying(36) NOT NULL
);


ALTER TABLE public.instruction_data_source_association OWNER TO kashika;

--
-- Name: instruction_references; Type: TABLE; Schema: public; Owner: kashika
--

CREATE TABLE public.instruction_references (
    instruction_id character varying(36) NOT NULL,
    object_type character varying(50) NOT NULL,
    object_id character varying(36) NOT NULL,
    column_name character varying(255),
    relation_type character varying(50),
    display_text character varying(255),
    id character varying(36) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone
);


ALTER TABLE public.instruction_references OWNER TO kashika;

--
-- Name: instructions; Type: TABLE; Schema: public; Owner: kashika
--

CREATE TABLE public.instructions (
    text text NOT NULL,
    thumbs_up integer NOT NULL,
    user_id character varying(36) NOT NULL,
    organization_id character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone,
    status character varying(50) DEFAULT 'draft'::character varying NOT NULL,
    category character varying(50) DEFAULT 'general'::character varying NOT NULL,
    private_status character varying(50),
    global_status character varying(50),
    is_seen boolean NOT NULL,
    can_user_toggle boolean NOT NULL,
    reviewed_by_user_id character varying(36),
    source_instruction_id character varying(36),
    agent_execution_id character varying(36),
    ai_source character varying(255),
    trigger_reason character varying(255)
);


ALTER TABLE public.instructions OWNER TO kashika;

--
-- Name: llm_models; Type: TABLE; Schema: public; Owner: kashika
--

CREATE TABLE public.llm_models (
    name character varying NOT NULL,
    model_id character varying NOT NULL,
    is_custom boolean,
    config json,
    is_preset boolean NOT NULL,
    is_enabled boolean NOT NULL,
    is_default boolean NOT NULL,
    provider_id character varying NOT NULL,
    id character varying(36) NOT NULL,
    organization_id character varying NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone
);


ALTER TABLE public.llm_models OWNER TO kashika;

--
-- Name: llm_providers; Type: TABLE; Schema: public; Owner: kashika
--

CREATE TABLE public.llm_providers (
    name character varying NOT NULL,
    provider_type character varying NOT NULL,
    api_key text,
    api_secret text,
    additional_config json,
    organization_id character varying NOT NULL,
    is_preset boolean NOT NULL,
    is_enabled boolean NOT NULL,
    use_preset_credentials boolean NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone
);


ALTER TABLE public.llm_providers OWNER TO kashika;

--
-- Name: memberships; Type: TABLE; Schema: public; Owner: kashika
--

CREATE TABLE public.memberships (
    user_id character varying(36),
    organization_id character varying(36) NOT NULL,
    role character varying NOT NULL,
    id character varying(36) NOT NULL,
    email character varying,
    invite_token character varying(36),
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone
);


ALTER TABLE public.memberships OWNER TO kashika;

--
-- Name: memories; Type: TABLE; Schema: public; Owner: kashika
--

CREATE TABLE public.memories (
    title character varying NOT NULL,
    description character varying,
    user_id character varying(36),
    organization_id character varying(36),
    step_id character varying(36),
    report_id character varying(36),
    is_public boolean,
    id character varying(36) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone,
    widget_id character varying(36)
);


ALTER TABLE public.memories OWNER TO kashika;

--
-- Name: mentions; Type: TABLE; Schema: public; Owner: kashika
--

CREATE TABLE public.mentions (
    type public.mentiontype NOT NULL,
    report_id character varying(36) NOT NULL,
    object_id character varying(36) NOT NULL,
    mention_content character varying NOT NULL,
    completion_id character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone
);


ALTER TABLE public.mentions OWNER TO kashika;

--
-- Name: metadata_indexing_jobs; Type: TABLE; Schema: public; Owner: kashika
--

CREATE TABLE public.metadata_indexing_jobs (
    data_source_id character varying(36) NOT NULL,
    organization_id character varying(36) NOT NULL,
    job_type character varying NOT NULL,
    status character varying NOT NULL,
    started_at timestamp without time zone,
    completed_at timestamp without time zone,
    total_resources integer,
    processed_resources integer,
    error_message text,
    error_details json,
    config json,
    summary json,
    raw_data json,
    is_active boolean NOT NULL,
    git_repository_id character varying(36),
    id character varying(36) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone,
    detected_project_types json
);


ALTER TABLE public.metadata_indexing_jobs OWNER TO kashika;

--
-- Name: metadata_resources; Type: TABLE; Schema: public; Owner: kashika
--

CREATE TABLE public.metadata_resources (
    name character varying NOT NULL,
    resource_type character varying NOT NULL,
    path character varying,
    description text,
    raw_data json,
    sql_content text,
    source_name character varying,
    database character varying,
    schema character varying,
    columns json,
    depends_on json,
    is_active boolean NOT NULL,
    last_synced_at timestamp without time zone,
    data_source_id character varying(36) NOT NULL,
    metadata_indexing_job_id character varying(36),
    id character varying(36) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone
);


ALTER TABLE public.metadata_resources OWNER TO kashika;

--
-- Name: oauth_accounts; Type: TABLE; Schema: public; Owner: kashika
--

CREATE TABLE public.oauth_accounts (
    id character varying(36) NOT NULL,
    user_id character varying(36) NOT NULL,
    oauth_name character varying(100) NOT NULL,
    access_token text NOT NULL,
    expires_at integer,
    refresh_token text,
    account_id character varying(320) NOT NULL,
    account_email character varying(320) NOT NULL
);


ALTER TABLE public.oauth_accounts OWNER TO kashika;

--
-- Name: organization_settings; Type: TABLE; Schema: public; Owner: kashika
--

CREATE TABLE public.organization_settings (
    organization_id character varying NOT NULL,
    config json NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone
);


ALTER TABLE public.organization_settings OWNER TO kashika;

--
-- Name: organizations; Type: TABLE; Schema: public; Owner: kashika
--

CREATE TABLE public.organizations (
    name character varying NOT NULL,
    description character varying,
    id character varying(36) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone
);


ALTER TABLE public.organizations OWNER TO kashika;

--
-- Name: plan_decisions; Type: TABLE; Schema: public; Owner: kashika
--

CREATE TABLE public.plan_decisions (
    agent_execution_id character varying(36) NOT NULL,
    seq integer NOT NULL,
    loop_index integer NOT NULL,
    plan_type character varying,
    analysis_complete boolean NOT NULL,
    reasoning character varying,
    assistant character varying,
    final_answer character varying,
    action_name character varying,
    action_args_json json,
    metrics_json json,
    context_snapshot_id character varying(36),
    id character varying(36) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone
);


ALTER TABLE public.plan_decisions OWNER TO kashika;

--
-- Name: plans; Type: TABLE; Schema: public; Owner: kashika
--

CREATE TABLE public.plans (
    content json NOT NULL,
    completion_id character varying(36),
    report_id character varying(36),
    organization_id character varying(36),
    user_id character varying(36),
    id character varying(36) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone
);


ALTER TABLE public.plans OWNER TO kashika;

--
-- Name: prompts; Type: TABLE; Schema: public; Owner: kashika
--

CREATE TABLE public.prompts (
    title character varying,
    text character varying NOT NULL,
    user_id character varying(36),
    organization_id character varying(36),
    id character varying(36) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone
);


ALTER TABLE public.prompts OWNER TO kashika;

--
-- Name: queries; Type: TABLE; Schema: public; Owner: kashika
--

CREATE TABLE public.queries (
    title character varying NOT NULL,
    description character varying,
    report_id character varying(36),
    widget_id character varying(36) NOT NULL,
    default_step_id character varying(36),
    organization_id character varying(36),
    user_id character varying(36),
    id character varying(36) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone
);


ALTER TABLE public.queries OWNER TO kashika;

--
-- Name: report_data_source_association; Type: TABLE; Schema: public; Owner: kashika
--

CREATE TABLE public.report_data_source_association (
    report_id character varying(36),
    data_source_id character varying(36)
);


ALTER TABLE public.report_data_source_association OWNER TO kashika;

--
-- Name: report_file_association; Type: TABLE; Schema: public; Owner: kashika
--

CREATE TABLE public.report_file_association (
    report_id character varying(36) NOT NULL,
    file_id character varying(36) NOT NULL
);


ALTER TABLE public.report_file_association OWNER TO kashika;

--
-- Name: reports; Type: TABLE; Schema: public; Owner: kashika
--

CREATE TABLE public.reports (
    title character varying NOT NULL,
    slug character varying NOT NULL,
    status character varying NOT NULL,
    cron_schedule character varying,
    id character varying(36) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone,
    user_id character varying(36) NOT NULL,
    organization_id character varying(36) NOT NULL,
    external_platform_id character varying(36),
    theme_name character varying,
    theme_overrides json
);


ALTER TABLE public.reports OWNER TO kashika;

--
-- Name: sheet_schemas; Type: TABLE; Schema: public; Owner: kashika
--

CREATE TABLE public.sheet_schemas (
    schema json,
    sheet_name character varying,
    sheet_index integer,
    file_id character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone
);


ALTER TABLE public.sheet_schemas OWNER TO kashika;

--
-- Name: steps; Type: TABLE; Schema: public; Owner: kashika
--

CREATE TABLE public.steps (
    title character varying NOT NULL,
    slug character varying NOT NULL,
    status character varying NOT NULL,
    prompt text NOT NULL,
    code text NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone,
    widget_id character varying(36),
    data json,
    description text DEFAULT ''::text NOT NULL,
    type character varying DEFAULT 'table'::character varying NOT NULL,
    data_model json,
    status_reason character varying,
    view json,
    query_id character varying(36)
);


ALTER TABLE public.steps OWNER TO kashika;

--
-- Name: table_feedback_events; Type: TABLE; Schema: public; Owner: kashika
--

CREATE TABLE public.table_feedback_events (
    org_id character varying(36) NOT NULL,
    report_id character varying(36),
    data_source_id character varying(36),
    step_id character varying(36),
    completion_feedback_id character varying(36) NOT NULL,
    table_fqn text NOT NULL,
    datasource_table_id character varying(36),
    feedback_type character varying(16) NOT NULL,
    created_at_event timestamp without time zone NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone
);


ALTER TABLE public.table_feedback_events OWNER TO kashika;

--
-- Name: table_stats; Type: TABLE; Schema: public; Owner: kashika
--

CREATE TABLE public.table_stats (
    org_id character varying(36) NOT NULL,
    report_id character varying(36),
    data_source_id character varying(36),
    table_fqn text NOT NULL,
    datasource_table_id character varying(36),
    usage_count bigint NOT NULL,
    success_count bigint NOT NULL,
    weighted_usage_count double precision NOT NULL,
    pos_feedback_count bigint NOT NULL,
    neg_feedback_count bigint NOT NULL,
    weighted_pos_feedback double precision NOT NULL,
    weighted_neg_feedback double precision NOT NULL,
    unique_users bigint NOT NULL,
    trusted_usage_count bigint NOT NULL,
    failure_count bigint NOT NULL,
    last_used_at timestamp without time zone,
    last_feedback_at timestamp without time zone,
    updated_at_stats timestamp without time zone NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone
);


ALTER TABLE public.table_stats OWNER TO kashika;

--
-- Name: table_usage_events; Type: TABLE; Schema: public; Owner: kashika
--

CREATE TABLE public.table_usage_events (
    org_id character varying(36) NOT NULL,
    report_id character varying(36),
    data_source_id character varying(36),
    step_id character varying(36) NOT NULL,
    user_id character varying(36),
    table_fqn text NOT NULL,
    datasource_table_id character varying(36),
    source_type character varying(32) NOT NULL,
    columns json,
    success boolean NOT NULL,
    user_role character varying(64),
    role_weight double precision,
    used_at timestamp without time zone NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone
);


ALTER TABLE public.table_usage_events OWNER TO kashika;

--
-- Name: text_widgets; Type: TABLE; Schema: public; Owner: kashika
--

CREATE TABLE public.text_widgets (
    status character varying NOT NULL,
    x integer NOT NULL,
    y integer NOT NULL,
    width integer NOT NULL,
    height integer NOT NULL,
    content character varying NOT NULL,
    report_id character varying(36) NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone,
    view json
);


ALTER TABLE public.text_widgets OWNER TO kashika;

--
-- Name: tool_executions; Type: TABLE; Schema: public; Owner: kashika
--

CREATE TABLE public.tool_executions (
    agent_execution_id character varying(36) NOT NULL,
    plan_decision_id character varying(36),
    tool_name character varying NOT NULL,
    tool_action character varying,
    arguments_json json NOT NULL,
    status character varying NOT NULL,
    success boolean NOT NULL,
    started_at timestamp without time zone,
    completed_at timestamp without time zone,
    duration_ms double precision,
    attempt_number integer NOT NULL,
    max_retries integer NOT NULL,
    token_usage_json json,
    result_summary character varying,
    result_json json,
    artifact_refs_json json,
    created_widget_id character varying(36),
    created_step_id character varying(36),
    context_snapshot_id character varying(36),
    error_message character varying,
    id character varying(36) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone
);


ALTER TABLE public.tool_executions OWNER TO kashika;

--
-- Name: user_data_source_columns; Type: TABLE; Schema: public; Owner: kashika
--

CREATE TABLE public.user_data_source_columns (
    user_data_source_table_id character varying(36) NOT NULL,
    column_name character varying NOT NULL,
    is_accessible boolean NOT NULL,
    is_masked boolean NOT NULL,
    data_type character varying,
    id character varying(36) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone
);


ALTER TABLE public.user_data_source_columns OWNER TO kashika;

--
-- Name: user_data_source_credentials; Type: TABLE; Schema: public; Owner: kashika
--

CREATE TABLE public.user_data_source_credentials (
    data_source_id character varying(36) NOT NULL,
    user_id character varying(36) NOT NULL,
    organization_id character varying(36) NOT NULL,
    auth_mode character varying(64) NOT NULL,
    encrypted_credentials text NOT NULL,
    is_active boolean NOT NULL,
    is_primary boolean NOT NULL,
    last_used_at timestamp without time zone,
    expires_at timestamp without time zone,
    metadata_json json,
    id character varying(36) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone
);


ALTER TABLE public.user_data_source_credentials OWNER TO kashika;

--
-- Name: user_data_source_tables; Type: TABLE; Schema: public; Owner: kashika
--

CREATE TABLE public.user_data_source_tables (
    data_source_id character varying(36) NOT NULL,
    user_id character varying(36) NOT NULL,
    table_name character varying NOT NULL,
    data_source_table_id character varying(36),
    is_accessible boolean NOT NULL,
    status character varying NOT NULL,
    metadata_json json,
    id character varying(36) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone
);


ALTER TABLE public.user_data_source_tables OWNER TO kashika;

--
-- Name: users; Type: TABLE; Schema: public; Owner: kashika
--

CREATE TABLE public.users (
    name character varying NOT NULL,
    last_login timestamp without time zone,
    id character varying(36) NOT NULL,
    email character varying(320) NOT NULL,
    hashed_password character varying(1024) NOT NULL,
    is_active boolean NOT NULL,
    is_superuser boolean NOT NULL,
    is_verified boolean NOT NULL
);


ALTER TABLE public.users OWNER TO kashika;

--
-- Name: visualizations; Type: TABLE; Schema: public; Owner: kashika
--

CREATE TABLE public.visualizations (
    title character varying NOT NULL,
    status character varying NOT NULL,
    report_id character varying(36) NOT NULL,
    query_id character varying(36) NOT NULL,
    view json,
    id character varying(36) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone
);


ALTER TABLE public.visualizations OWNER TO kashika;

--
-- Name: widgets; Type: TABLE; Schema: public; Owner: kashika
--

CREATE TABLE public.widgets (
    title character varying NOT NULL,
    slug character varying NOT NULL,
    status character varying NOT NULL,
    id character varying(36) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone,
    report_id character varying(36),
    x integer NOT NULL,
    y integer NOT NULL,
    width integer NOT NULL,
    height integer NOT NULL
);


ALTER TABLE public.widgets OWNER TO kashika;

--
-- Data for Name: agent_executions; Type: TABLE DATA; Schema: public; Owner: kashika
--

COPY public.agent_executions (completion_id, organization_id, user_id, report_id, status, started_at, completed_at, total_duration_ms, first_token_ms, thinking_ms, latest_seq, token_usage_json, error_json, config_json, id, bow_version, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: kashika
--

COPY public.alembic_version (version_num) FROM stdin;
95de3b2ebc88
\.


--
-- Data for Name: apscheduler_jobs; Type: TABLE DATA; Schema: public; Owner: kashika
--

COPY public.apscheduler_jobs (id, next_run_time, job_state) FROM stdin;
\.


--
-- Data for Name: completion_blocks; Type: TABLE DATA; Schema: public; Owner: kashika
--

COPY public.completion_blocks (completion_id, agent_execution_id, source_type, plan_decision_id, tool_execution_id, block_index, loop_index, title, status, icon, content, reasoning, started_at, completed_at, id, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: completion_feedbacks; Type: TABLE DATA; Schema: public; Owner: kashika
--

COPY public.completion_feedbacks (user_id, completion_id, organization_id, direction, message, reviewed_at, reviewed_by, id, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: completions; Type: TABLE DATA; Schema: public; Owner: kashika
--

COPY public.completions (id, prompt, completion, status, model, turn_index, parent_id, message_type, role, report_id, widget_id, step_id, created_at, updated_at, deleted_at, user_id, main_router, feedback_score, sigkill, external_platform, external_message_id, external_user_id, instructions_effectiveness, context_effectiveness, response_score) FROM stdin;
\.


--
-- Data for Name: context_snapshots; Type: TABLE DATA; Schema: public; Owner: kashika
--

COPY public.context_snapshots (agent_execution_id, kind, context_view_json, prompt_text, prompt_tokens, hash, id, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: dashboard_layout_versions; Type: TABLE DATA; Schema: public; Owner: kashika
--

COPY public.dashboard_layout_versions (name, version, is_active, theme_name, theme_overrides, blocks, report_id, id, created_at, updated_at, deleted_at) FROM stdin;
	1	t	default	{}	[]	f22c7249-cdab-4771-bd47-2f42653a6b17	f02963fc-63b4-409c-abb0-9289915ca745	2025-11-17 15:37:25.083108	2025-11-17 15:37:25.083111	\N
\.


--
-- Data for Name: data_source_memberships; Type: TABLE DATA; Schema: public; Owner: kashika
--

COPY public.data_source_memberships (data_source_id, principal_type, principal_id, config, id, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: data_sources; Type: TABLE DATA; Schema: public; Owner: kashika
--

COPY public.data_sources (name, type, config, last_synced_at, is_active, organization_id, id, created_at, updated_at, deleted_at, context, description, summary, conversation_starters, credentials, is_public, owner_user_id, use_llm_sync, auth_policy, allowed_user_auth_modes) FROM stdin;
\.


--
-- Data for Name: datasource_tables; Type: TABLE DATA; Schema: public; Owner: kashika
--

COPY public.datasource_tables (name, columns, no_rows, datasource_id, pks, fks, is_active, id, created_at, updated_at, deleted_at, centrality_score, richness, degree_in, degree_out, entity_like, metrics_computed_at, metadata_json) FROM stdin;
\.


--
-- Data for Name: entities; Type: TABLE DATA; Schema: public; Owner: kashika
--

COPY public.entities (organization_id, owner_id, type, title, slug, description, tags, code, data, original_data_model, view, status, published_at, pinned, last_refreshed_at, auto_refresh_enabled, auto_refresh_interval, auto_refresh_interval_unit, private_status, global_status, reviewed_by_user_id, source_step_id, trigger_reason, ai_source, id, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: entity_data_source_association; Type: TABLE DATA; Schema: public; Owner: kashika
--

COPY public.entity_data_source_association (entity_id, data_source_id) FROM stdin;
\.


--
-- Data for Name: external_platforms; Type: TABLE DATA; Schema: public; Owner: kashika
--

COPY public.external_platforms (organization_id, platform_type, platform_config, credentials, is_active, id, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: external_user_mappings; Type: TABLE DATA; Schema: public; Owner: kashika
--

COPY public.external_user_mappings (organization_id, platform_type, platform_id, external_user_id, external_email, external_name, app_user_id, is_verified, verification_token, verification_expires_at, last_verified_at, id, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: file_tags; Type: TABLE DATA; Schema: public; Owner: kashika
--

COPY public.file_tags (key, value, file_id, id, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: files; Type: TABLE DATA; Schema: public; Owner: kashika
--

COPY public.files (filename, path, content_type, id, created_at, updated_at, deleted_at, user_id, organization_id) FROM stdin;
\.


--
-- Data for Name: git_repositories; Type: TABLE DATA; Schema: public; Owner: kashika
--

COPY public.git_repositories (provider, repo_url, last_indexed_at, ssh_key, branch, is_active, status, user_id, data_source_id, organization_id, id, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: instruction_data_source_association; Type: TABLE DATA; Schema: public; Owner: kashika
--

COPY public.instruction_data_source_association (instruction_id, data_source_id) FROM stdin;
\.


--
-- Data for Name: instruction_references; Type: TABLE DATA; Schema: public; Owner: kashika
--

COPY public.instruction_references (instruction_id, object_type, object_id, column_name, relation_type, display_text, id, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: instructions; Type: TABLE DATA; Schema: public; Owner: kashika
--

COPY public.instructions (text, thumbs_up, user_id, organization_id, id, created_at, updated_at, deleted_at, status, category, private_status, global_status, is_seen, can_user_toggle, reviewed_by_user_id, source_instruction_id, agent_execution_id, ai_source, trigger_reason) FROM stdin;
\.


--
-- Data for Name: llm_models; Type: TABLE DATA; Schema: public; Owner: kashika
--

COPY public.llm_models (name, model_id, is_custom, config, is_preset, is_enabled, is_default, provider_id, id, organization_id, created_at, updated_at, deleted_at) FROM stdin;
GPT-4.1	gpt-4.1	f	\N	t	t	t	6e8a67ab-0b93-462b-be0d-7751c8d153cc	a2b8a02d-9a6e-418a-a6fb-299f2b140304	d5ad1390-7b23-469c-8145-340e92376736	2025-11-21 01:42:48.211106	2025-11-21 01:42:48.211108	\N
GPT-5	gpt-5	f	\N	t	t	f	6e8a67ab-0b93-462b-be0d-7751c8d153cc	1b74b668-5145-41ee-a06d-cd44d6572b2f	d5ad1390-7b23-469c-8145-340e92376736	2025-11-21 01:42:48.211094	2025-11-21 01:45:54.410041	\N
GPT-4.1 Mini	gpt-4.1-mini	f	\N	t	t	f	6e8a67ab-0b93-462b-be0d-7751c8d153cc	4cb7387f-e2a1-4334-9ac1-d49e077cdcd6	d5ad1390-7b23-469c-8145-340e92376736	2025-11-21 01:42:48.211114	2025-11-21 01:45:55.443632	\N
\.


--
-- Data for Name: llm_providers; Type: TABLE DATA; Schema: public; Owner: kashika
--

COPY public.llm_providers (name, provider_type, api_key, api_secret, additional_config, organization_id, is_preset, is_enabled, use_preset_credentials, id, created_at, updated_at, deleted_at) FROM stdin;
Kashika	openai	gAAAAABpH8RZoKhzXS5IXEIp8O6gTQkd-Z9CQuV0yBFDfFA7ue7u2tiss2V2uI8-KPaF1u7zccy6Ez9FJc1rliTWbcyYPO3f1BGh-BF7kFdaQea7tjsp3XULQ2AAjtBrkaRD8vpMYvVFgDNhurWcVDB6d0-_gIGN-fMo-_GCeIYidu1DUZpQgwYb2Q_cBCfga7TrjFNofyzn03XBbyFnMY-cRilTTJeyiCibSKraL6-61s4coS4WOSglW7UvZSUv4SJWVwT3xhd6V2asAC8oec_MiCQ7SKQYE-alkJGo-vpGAtxgPHyJzeY=	gAAAAABpH8RZTSVnIoUGgnmepn5mMuGGu7Sa41scUdjJVHFQRSxvIhJl7i6refHwVKvhOci-2CTd1GqIpVckobylcJBFPLX3_Q==	null	d5ad1390-7b23-469c-8145-340e92376736	f	t	t	6e8a67ab-0b93-462b-be0d-7751c8d153cc	2025-11-21 01:42:48.202801	2025-11-21 01:46:01.821485	\N
\.


--
-- Data for Name: memberships; Type: TABLE DATA; Schema: public; Owner: kashika
--

COPY public.memberships (user_id, organization_id, role, id, email, invite_token, created_at, updated_at, deleted_at) FROM stdin;
d962756b-219d-47e6-98f1-9663f15e5d26	d5ad1390-7b23-469c-8145-340e92376736	admin	ccae8ff8-0090-4d87-af3e-82dfc2876285	\N	ce449a7f-525b-45c1-b876-349b3c31ab9d	2025-11-17 15:37:04.485046	2025-11-17 15:37:04.485048	\N
\.


--
-- Data for Name: memories; Type: TABLE DATA; Schema: public; Owner: kashika
--

COPY public.memories (title, description, user_id, organization_id, step_id, report_id, is_public, id, created_at, updated_at, deleted_at, widget_id) FROM stdin;
\.


--
-- Data for Name: mentions; Type: TABLE DATA; Schema: public; Owner: kashika
--

COPY public.mentions (type, report_id, object_id, mention_content, completion_id, id, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: metadata_indexing_jobs; Type: TABLE DATA; Schema: public; Owner: kashika
--

COPY public.metadata_indexing_jobs (data_source_id, organization_id, job_type, status, started_at, completed_at, total_resources, processed_resources, error_message, error_details, config, summary, raw_data, is_active, git_repository_id, id, created_at, updated_at, deleted_at, detected_project_types) FROM stdin;
\.


--
-- Data for Name: metadata_resources; Type: TABLE DATA; Schema: public; Owner: kashika
--

COPY public.metadata_resources (name, resource_type, path, description, raw_data, sql_content, source_name, database, schema, columns, depends_on, is_active, last_synced_at, data_source_id, metadata_indexing_job_id, id, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: oauth_accounts; Type: TABLE DATA; Schema: public; Owner: kashika
--

COPY public.oauth_accounts (id, user_id, oauth_name, access_token, expires_at, refresh_token, account_id, account_email) FROM stdin;
0f3b9427-db46-4989-a574-2515abe0d4df	d962756b-219d-47e6-98f1-9663f15e5d26	keycloak	eyJhbGciOiJSUzI1NiIsInR5cCIgOiAiSldUIiwia2lkIiA6ICJzU1BYcGxTWHE3Wk9BYV95NFExY19lS0JndExnTXhvWXA2SERJNW5HYmxRIn0.eyJleHAiOjE3NjMzOTQxMjQsImlhdCI6MTc2MzM5MzgyNCwiYXV0aF90aW1lIjoxNzYzMzkzODI0LCJqdGkiOiJiMmVjMjk2OC1lZDUyLTQ5MzQtOTE4Yi1iNWQ2Yzk2N2MzZTUiLCJpc3MiOiJodHRwOi8vbG9jYWxob3N0OjgwOTAvcmVhbG1zL2thc2hpa2EtYWkiLCJhdWQiOiJhY2NvdW50Iiwic3ViIjoiYzRkYjdkNDAtMjRkYi00NmE2LTlmOTYtNGQ1YzY5ZTg2NmYzIiwidHlwIjoiQmVhcmVyIiwiYXpwIjoia2FzaGlrYS1haSIsInNpZCI6IjAxMGExNzYxLWFiMjItNDE5MC05MDU1LTkyMTZjYTRjMGRkZiIsImFjciI6IjEiLCJhbGxvd2VkLW9yaWdpbnMiOlsiaHR0cDovL2xvY2FsaG9zdDozMDAwIl0sInJlYWxtX2FjY2VzcyI6eyJyb2xlcyI6WyJvZmZsaW5lX2FjY2VzcyIsInVtYV9hdXRob3JpemF0aW9uIiwiZGVmYXVsdC1yb2xlcy1rYXNoaWthLWFpIl19LCJyZXNvdXJjZV9hY2Nlc3MiOnsiYWNjb3VudCI6eyJyb2xlcyI6WyJtYW5hZ2UtYWNjb3VudCIsIm1hbmFnZS1hY2NvdW50LWxpbmtzIiwidmlldy1wcm9maWxlIl19fSwic2NvcGUiOiJvcGVuaWQgcHJvZmlsZSBlbWFpbCIsImVtYWlsX3ZlcmlmaWVkIjpmYWxzZSwibmFtZSI6IlNyaWhhcnNoYSBFZWR1cHVnYW50aSBFZWR1cHVnYW50aSIsInByZWZlcnJlZF91c2VybmFtZSI6InNlZHVwdWdhbnRpIiwiZ2l2ZW5fbmFtZSI6IlNyaWhhcnNoYSBFZWR1cHVnYW50aSIsImZhbWlseV9uYW1lIjoiRWVkdXB1Z2FudGkiLCJlbWFpbCI6ImRldmVsb3BlckBpbm5kYXRhLmluIn0.rmo0P1R2_Tknb2Tz7AwjyrdIOu4pmEzmc6SZEkeSCWdxqeHY_Hs03xduPlIWOys-WeOsO7-qFAyegyiyTdF4KRj3BNJ8z8nibEkRDZmdTQi514-uKnAIe6pNC_DXfU2tbSKytcfLralT22C8DG43vIKl8N9EHCFT2YFNGiIgR4ZWee7JZVst6h6oEIyVtxxW9--Dic0ENyNfjcYnaBiNitTi9SKuq7gb56yZyUCv1E4IFK6jKgRuD7X35Q0nV0KckCghyFNpqoc1n_ob9MveIZM7Mq78kewhEmazIrYvhMtV_PjeAb1cuadLXdWvX4Emg8Lp8dtKJgn_telng7b5pw	1763394124	eyJhbGciOiJIUzUxMiIsInR5cCIgOiAiSldUIiwia2lkIiA6ICJlYTkyZjM2Yy1iOWI3LTQzM2EtOGQwMi01MzM3ODQ0YzRkZTYifQ.eyJleHAiOjE3NjMzOTU2MjQsImlhdCI6MTc2MzM5MzgyNCwianRpIjoiMTZhZGNlYjItYzNkNC00YmNiLTg5ZGEtOWEwZWQ2OTIxZWJlIiwiaXNzIjoiaHR0cDovL2xvY2FsaG9zdDo4MDkwL3JlYWxtcy9rYXNoaWthLWFpIiwiYXVkIjoiaHR0cDovL2xvY2FsaG9zdDo4MDkwL3JlYWxtcy9rYXNoaWthLWFpIiwic3ViIjoiYzRkYjdkNDAtMjRkYi00NmE2LTlmOTYtNGQ1YzY5ZTg2NmYzIiwidHlwIjoiUmVmcmVzaCIsImF6cCI6Imthc2hpa2EtYWkiLCJzaWQiOiIwMTBhMTc2MS1hYjIyLTQxOTAtOTA1NS05MjE2Y2E0YzBkZGYiLCJzY29wZSI6Im9wZW5pZCByb2xlcyB3ZWItb3JpZ2lucyBwcm9maWxlIGJhc2ljIGFjciBlbWFpbCJ9.k9-Zz_YXB-SzYiI08K4_XgJ42m2AScjXNRlixHmL12KNGdQXIoDWJlAudLzgoQZ92fwPVX6PBqwmQJ6ZURejjA	c4db7d40-24db-46a6-9f96-4d5c69e866f3	developer@inndata.in
\.


--
-- Data for Name: organization_settings; Type: TABLE DATA; Schema: public; Owner: kashika
--

COPY public.organization_settings (organization_id, config, id, created_at, updated_at, deleted_at) FROM stdin;
d5ad1390-7b23-469c-8145-340e92376736	{"general": {"ai_analyst_name": "AI Analyst", "bow_credit": true, "icon_key": null, "icon_url": null}, "allow_llm_see_data": {"value": true, "name": "Allow LLM to see data", "description": "Enable LLM to see data as part of the analysis and user queries", "is_lab": false, "editable": true, "state": "enabled"}, "enable_file_upload": {"value": true, "name": "Allow file upload", "description": "Allow users to upload spreadsheets and docuemnts (xls/pdf) and push their content to the LLM", "is_lab": false, "editable": true, "state": "enabled"}, "enable_code_editing": {"value": true, "name": "Allow users to edit and execute the LLM generated code", "description": "Allow users to edit and execute the LLM generated code", "is_lab": false, "editable": true, "state": "enabled"}, "enable_llm_judgement": {"value": true, "name": "Enable LLM Judge", "description": "Enable LLM to judge the quality of the analysis and user queries", "is_lab": false, "editable": true, "state": "enabled"}, "suggest_instructions": {"value": true, "name": "Autogenerate instructions", "description": "Automatically generate instructions following clarifications provided by the user", "is_lab": false, "editable": true, "state": "enabled"}, "validate_code": {"value": true, "name": "Validate code", "description": "Validate the code generated by the LLM", "is_lab": false, "editable": true, "state": "enabled"}, "limit_analysis_steps": {"value": 6, "name": "Limit analysis steps", "description": "Limit the number of analysis steps that can be used in the analysis", "is_lab": false, "editable": false, "state": "enabled"}, "limit_code_retries": {"value": 3, "name": "Limit code retries", "description": "Limit the number of times the LLM can retry code generation", "is_lab": false, "editable": false, "state": "enabled"}, "ai_features": {"planner": {"value": true, "name": "Planner", "description": "Orchestrates analysis by breaking down user requests into actionable steps", "is_lab": false, "editable": false, "state": "enabled"}, "coder": {"value": true, "name": "Coder", "description": "Translates data models into executable Python code for data processing", "is_lab": false, "editable": false, "state": "enabled"}, "validator": {"value": true, "name": "Validator", "description": "Validates code safety and integrity and its data model compatibility", "is_lab": false, "editable": true, "state": "enabled"}, "dashboard_designer": {"value": true, "name": "Dashboard Designer", "description": "Creates layout and organization of dashboard elements", "is_lab": false, "editable": true, "state": "enabled"}, "analyze_data": {"value": false, "name": "Analyze Data", "description": "Provides natural language responses to user questions about their data", "is_lab": false, "editable": false, "state": "disabled"}, "code_reviewer": {"value": false, "name": "Code Reviewer", "description": "Allow users to get feedback on their code", "is_lab": false, "editable": true, "state": "disabled"}, "search_context": {"value": true, "name": "Search Context", "description": "Allow users to search through metadata, context, and data models", "is_lab": false, "editable": true, "state": "enabled"}}, "onboarding": {"version": "v1", "current_step": "data_source_created", "completed": false, "dismissed": true, "steps": {"organization_created": {"status": "done", "ts": "2025-11-21T01:43:27.906804"}, "llm_configured": {"status": "done", "ts": "2025-11-21T01:43:27.906804"}, "data_source_created": {"status": "pending", "ts": null}, "schema_selected": {"status": "pending", "ts": null}, "instructions_added": {"status": "pending", "ts": null}}}}	3e5ba2ae-749a-40d4-9e93-3bc485fa2bb6	2025-11-17 15:37:04.480994	2025-11-21 01:43:27.907186	\N
\.


--
-- Data for Name: organizations; Type: TABLE DATA; Schema: public; Owner: kashika
--

COPY public.organizations (name, description, id, created_at, updated_at, deleted_at) FROM stdin;
Main Org		d5ad1390-7b23-469c-8145-340e92376736	2025-11-17 15:37:04.477575	2025-11-17 15:37:04.477584	\N
\.


--
-- Data for Name: plan_decisions; Type: TABLE DATA; Schema: public; Owner: kashika
--

COPY public.plan_decisions (agent_execution_id, seq, loop_index, plan_type, analysis_complete, reasoning, assistant, final_answer, action_name, action_args_json, metrics_json, context_snapshot_id, id, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: plans; Type: TABLE DATA; Schema: public; Owner: kashika
--

COPY public.plans (content, completion_id, report_id, organization_id, user_id, id, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: prompts; Type: TABLE DATA; Schema: public; Owner: kashika
--

COPY public.prompts (title, text, user_id, organization_id, id, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: queries; Type: TABLE DATA; Schema: public; Owner: kashika
--

COPY public.queries (title, description, report_id, widget_id, default_step_id, organization_id, user_id, id, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: report_data_source_association; Type: TABLE DATA; Schema: public; Owner: kashika
--

COPY public.report_data_source_association (report_id, data_source_id) FROM stdin;
\.


--
-- Data for Name: report_file_association; Type: TABLE DATA; Schema: public; Owner: kashika
--

COPY public.report_file_association (report_id, file_id) FROM stdin;
\.


--
-- Data for Name: reports; Type: TABLE DATA; Schema: public; Owner: kashika
--

COPY public.reports (title, slug, status, cron_schedule, id, created_at, updated_at, deleted_at, user_id, organization_id, external_platform_id, theme_name, theme_overrides) FROM stdin;
untitled report	untitled-report-2eb6	draft	\N	f22c7249-cdab-4771-bd47-2f42653a6b17	2025-11-17 15:37:25.046196	2025-11-17 15:37:25.0462	\N	d962756b-219d-47e6-98f1-9663f15e5d26	d5ad1390-7b23-469c-8145-340e92376736	\N	default	{}
\.


--
-- Data for Name: sheet_schemas; Type: TABLE DATA; Schema: public; Owner: kashika
--

COPY public.sheet_schemas (schema, sheet_name, sheet_index, file_id, id, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: steps; Type: TABLE DATA; Schema: public; Owner: kashika
--

COPY public.steps (title, slug, status, prompt, code, id, created_at, updated_at, deleted_at, widget_id, data, description, type, data_model, status_reason, view, query_id) FROM stdin;
\.


--
-- Data for Name: table_feedback_events; Type: TABLE DATA; Schema: public; Owner: kashika
--

COPY public.table_feedback_events (org_id, report_id, data_source_id, step_id, completion_feedback_id, table_fqn, datasource_table_id, feedback_type, created_at_event, id, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: table_stats; Type: TABLE DATA; Schema: public; Owner: kashika
--

COPY public.table_stats (org_id, report_id, data_source_id, table_fqn, datasource_table_id, usage_count, success_count, weighted_usage_count, pos_feedback_count, neg_feedback_count, weighted_pos_feedback, weighted_neg_feedback, unique_users, trusted_usage_count, failure_count, last_used_at, last_feedback_at, updated_at_stats, id, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: table_usage_events; Type: TABLE DATA; Schema: public; Owner: kashika
--

COPY public.table_usage_events (org_id, report_id, data_source_id, step_id, user_id, table_fqn, datasource_table_id, source_type, columns, success, user_role, role_weight, used_at, id, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: text_widgets; Type: TABLE DATA; Schema: public; Owner: kashika
--

COPY public.text_widgets (status, x, y, width, height, content, report_id, id, created_at, updated_at, deleted_at, view) FROM stdin;
\.


--
-- Data for Name: tool_executions; Type: TABLE DATA; Schema: public; Owner: kashika
--

COPY public.tool_executions (agent_execution_id, plan_decision_id, tool_name, tool_action, arguments_json, status, success, started_at, completed_at, duration_ms, attempt_number, max_retries, token_usage_json, result_summary, result_json, artifact_refs_json, created_widget_id, created_step_id, context_snapshot_id, error_message, id, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: user_data_source_columns; Type: TABLE DATA; Schema: public; Owner: kashika
--

COPY public.user_data_source_columns (user_data_source_table_id, column_name, is_accessible, is_masked, data_type, id, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: user_data_source_credentials; Type: TABLE DATA; Schema: public; Owner: kashika
--

COPY public.user_data_source_credentials (data_source_id, user_id, organization_id, auth_mode, encrypted_credentials, is_active, is_primary, last_used_at, expires_at, metadata_json, id, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: user_data_source_tables; Type: TABLE DATA; Schema: public; Owner: kashika
--

COPY public.user_data_source_tables (data_source_id, user_id, table_name, data_source_table_id, is_accessible, status, metadata_json, id, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: kashika
--

COPY public.users (name, last_login, id, email, hashed_password, is_active, is_superuser, is_verified) FROM stdin;
developer	\N	d962756b-219d-47e6-98f1-9663f15e5d26	developer@inndata.in	$argon2id$v=19$m=65536,t=3,p=4$qg54lauS1jWm1k7XseQL6Q$hlb9KfKbTd2OS+fLU8BgX65NtjZPjQeLFdC5eFBwS9o	t	f	t
\.


--
-- Data for Name: visualizations; Type: TABLE DATA; Schema: public; Owner: kashika
--

COPY public.visualizations (title, status, report_id, query_id, view, id, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: widgets; Type: TABLE DATA; Schema: public; Owner: kashika
--

COPY public.widgets (title, slug, status, id, created_at, updated_at, deleted_at, report_id, x, y, width, height) FROM stdin;
\.


--
-- Name: agent_executions agent_executions_pkey; Type: CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.agent_executions
    ADD CONSTRAINT agent_executions_pkey PRIMARY KEY (id);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: apscheduler_jobs apscheduler_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.apscheduler_jobs
    ADD CONSTRAINT apscheduler_jobs_pkey PRIMARY KEY (id);


--
-- Name: completion_blocks completion_blocks_pkey; Type: CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.completion_blocks
    ADD CONSTRAINT completion_blocks_pkey PRIMARY KEY (id);


--
-- Name: completion_feedbacks completion_feedbacks_pkey; Type: CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.completion_feedbacks
    ADD CONSTRAINT completion_feedbacks_pkey PRIMARY KEY (id);


--
-- Name: completions completions_pkey; Type: CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.completions
    ADD CONSTRAINT completions_pkey PRIMARY KEY (id);


--
-- Name: context_snapshots context_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.context_snapshots
    ADD CONSTRAINT context_snapshots_pkey PRIMARY KEY (id);


--
-- Name: dashboard_layout_versions dashboard_layout_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.dashboard_layout_versions
    ADD CONSTRAINT dashboard_layout_versions_pkey PRIMARY KEY (id);


--
-- Name: data_source_memberships data_source_memberships_pkey; Type: CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.data_source_memberships
    ADD CONSTRAINT data_source_memberships_pkey PRIMARY KEY (id);


--
-- Name: data_sources data_sources_pkey; Type: CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.data_sources
    ADD CONSTRAINT data_sources_pkey PRIMARY KEY (id);


--
-- Name: datasource_tables datasource_tables_pkey; Type: CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.datasource_tables
    ADD CONSTRAINT datasource_tables_pkey PRIMARY KEY (id);


--
-- Name: entities entities_pkey; Type: CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.entities
    ADD CONSTRAINT entities_pkey PRIMARY KEY (id);


--
-- Name: external_platforms external_platforms_pkey; Type: CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.external_platforms
    ADD CONSTRAINT external_platforms_pkey PRIMARY KEY (id);


--
-- Name: external_user_mappings external_user_mappings_pkey; Type: CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.external_user_mappings
    ADD CONSTRAINT external_user_mappings_pkey PRIMARY KEY (id);


--
-- Name: external_user_mappings external_user_mappings_verification_token_key; Type: CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.external_user_mappings
    ADD CONSTRAINT external_user_mappings_verification_token_key UNIQUE (verification_token);


--
-- Name: file_tags file_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.file_tags
    ADD CONSTRAINT file_tags_pkey PRIMARY KEY (id);


--
-- Name: files files_pkey; Type: CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.files
    ADD CONSTRAINT files_pkey PRIMARY KEY (id);


--
-- Name: git_repositories git_repositories_pkey; Type: CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.git_repositories
    ADD CONSTRAINT git_repositories_pkey PRIMARY KEY (id);


--
-- Name: instruction_data_source_association instruction_data_source_association_pkey; Type: CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.instruction_data_source_association
    ADD CONSTRAINT instruction_data_source_association_pkey PRIMARY KEY (instruction_id, data_source_id);


--
-- Name: instruction_references instruction_references_pkey; Type: CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.instruction_references
    ADD CONSTRAINT instruction_references_pkey PRIMARY KEY (id);


--
-- Name: instructions instructions_pkey; Type: CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.instructions
    ADD CONSTRAINT instructions_pkey PRIMARY KEY (id);


--
-- Name: llm_models llm_models_pkey; Type: CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.llm_models
    ADD CONSTRAINT llm_models_pkey PRIMARY KEY (id);


--
-- Name: llm_providers llm_providers_pkey; Type: CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.llm_providers
    ADD CONSTRAINT llm_providers_pkey PRIMARY KEY (id);


--
-- Name: memberships memberships_invite_token_key; Type: CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.memberships
    ADD CONSTRAINT memberships_invite_token_key UNIQUE (invite_token);


--
-- Name: memberships memberships_pkey; Type: CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.memberships
    ADD CONSTRAINT memberships_pkey PRIMARY KEY (id);


--
-- Name: memories memories_pkey; Type: CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.memories
    ADD CONSTRAINT memories_pkey PRIMARY KEY (id);


--
-- Name: mentions mentions_pkey; Type: CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.mentions
    ADD CONSTRAINT mentions_pkey PRIMARY KEY (id);


--
-- Name: metadata_indexing_jobs metadata_indexing_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.metadata_indexing_jobs
    ADD CONSTRAINT metadata_indexing_jobs_pkey PRIMARY KEY (id);


--
-- Name: metadata_resources metadata_resources_pkey; Type: CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.metadata_resources
    ADD CONSTRAINT metadata_resources_pkey PRIMARY KEY (id);


--
-- Name: oauth_accounts oauth_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.oauth_accounts
    ADD CONSTRAINT oauth_accounts_pkey PRIMARY KEY (id);


--
-- Name: organization_settings organization_settings_organization_id_key; Type: CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.organization_settings
    ADD CONSTRAINT organization_settings_organization_id_key UNIQUE (organization_id);


--
-- Name: organization_settings organization_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.organization_settings
    ADD CONSTRAINT organization_settings_pkey PRIMARY KEY (id);


--
-- Name: organizations organizations_pkey; Type: CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT organizations_pkey PRIMARY KEY (id);


--
-- Name: plan_decisions plan_decisions_pkey; Type: CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.plan_decisions
    ADD CONSTRAINT plan_decisions_pkey PRIMARY KEY (id);


--
-- Name: plans plans_pkey; Type: CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.plans
    ADD CONSTRAINT plans_pkey PRIMARY KEY (id);


--
-- Name: prompts prompts_pkey; Type: CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.prompts
    ADD CONSTRAINT prompts_pkey PRIMARY KEY (id);


--
-- Name: queries queries_pkey; Type: CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.queries
    ADD CONSTRAINT queries_pkey PRIMARY KEY (id);


--
-- Name: report_file_association report_file_association_pkey; Type: CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.report_file_association
    ADD CONSTRAINT report_file_association_pkey PRIMARY KEY (report_id, file_id);


--
-- Name: reports reports_pkey; Type: CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.reports
    ADD CONSTRAINT reports_pkey PRIMARY KEY (id);


--
-- Name: sheet_schemas sheet_schemas_pkey; Type: CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.sheet_schemas
    ADD CONSTRAINT sheet_schemas_pkey PRIMARY KEY (id);


--
-- Name: steps steps_pkey; Type: CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.steps
    ADD CONSTRAINT steps_pkey PRIMARY KEY (id);


--
-- Name: table_feedback_events table_feedback_events_pkey; Type: CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.table_feedback_events
    ADD CONSTRAINT table_feedback_events_pkey PRIMARY KEY (id);


--
-- Name: table_stats table_stats_pkey; Type: CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.table_stats
    ADD CONSTRAINT table_stats_pkey PRIMARY KEY (id);


--
-- Name: table_usage_events table_usage_events_pkey; Type: CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.table_usage_events
    ADD CONSTRAINT table_usage_events_pkey PRIMARY KEY (id);


--
-- Name: text_widgets text_widgets_pkey; Type: CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.text_widgets
    ADD CONSTRAINT text_widgets_pkey PRIMARY KEY (id);


--
-- Name: tool_executions tool_executions_pkey; Type: CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.tool_executions
    ADD CONSTRAINT tool_executions_pkey PRIMARY KEY (id);


--
-- Name: external_user_mappings unique_external_user; Type: CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.external_user_mappings
    ADD CONSTRAINT unique_external_user UNIQUE (organization_id, platform_type, external_user_id);


--
-- Name: completion_blocks uq_blocks_completion_block_index; Type: CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.completion_blocks
    ADD CONSTRAINT uq_blocks_completion_block_index UNIQUE (completion_id, block_index);


--
-- Name: completion_blocks uq_blocks_source; Type: CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.completion_blocks
    ADD CONSTRAINT uq_blocks_source UNIQUE (agent_execution_id, source_type, plan_decision_id, tool_execution_id);


--
-- Name: data_source_memberships uq_data_source_membership; Type: CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.data_source_memberships
    ADD CONSTRAINT uq_data_source_membership UNIQUE (data_source_id, principal_type, principal_id);


--
-- Name: entity_data_source_association uq_entity_data_source; Type: CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.entity_data_source_association
    ADD CONSTRAINT uq_entity_data_source PRIMARY KEY (entity_id, data_source_id);


--
-- Name: plan_decisions uq_plan_decisions_execution_seq; Type: CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.plan_decisions
    ADD CONSTRAINT uq_plan_decisions_execution_seq UNIQUE (agent_execution_id, seq);


--
-- Name: table_usage_events uq_usage_step_table; Type: CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.table_usage_events
    ADD CONSTRAINT uq_usage_step_table UNIQUE (step_id, table_fqn);


--
-- Name: user_data_source_tables uq_user_ds_table; Type: CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.user_data_source_tables
    ADD CONSTRAINT uq_user_ds_table UNIQUE (data_source_id, user_id, table_name);


--
-- Name: user_data_source_columns uq_user_ds_table_column; Type: CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.user_data_source_columns
    ADD CONSTRAINT uq_user_ds_table_column UNIQUE (user_data_source_table_id, column_name);


--
-- Name: user_data_source_columns user_data_source_columns_pkey; Type: CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.user_data_source_columns
    ADD CONSTRAINT user_data_source_columns_pkey PRIMARY KEY (id);


--
-- Name: user_data_source_credentials user_data_source_credentials_pkey; Type: CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.user_data_source_credentials
    ADD CONSTRAINT user_data_source_credentials_pkey PRIMARY KEY (id);


--
-- Name: user_data_source_tables user_data_source_tables_pkey; Type: CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.user_data_source_tables
    ADD CONSTRAINT user_data_source_tables_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: visualizations visualizations_pkey; Type: CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.visualizations
    ADD CONSTRAINT visualizations_pkey PRIMARY KEY (id);


--
-- Name: widgets widgets_pkey; Type: CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.widgets
    ADD CONSTRAINT widgets_pkey PRIMARY KEY (id);


--
-- Name: ix_agent_executions_bow_version; Type: INDEX; Schema: public; Owner: kashika
--

CREATE INDEX ix_agent_executions_bow_version ON public.agent_executions USING btree (bow_version);


--
-- Name: ix_agent_executions_completion_id; Type: INDEX; Schema: public; Owner: kashika
--

CREATE INDEX ix_agent_executions_completion_id ON public.agent_executions USING btree (completion_id);


--
-- Name: ix_agent_executions_id; Type: INDEX; Schema: public; Owner: kashika
--

CREATE UNIQUE INDEX ix_agent_executions_id ON public.agent_executions USING btree (id);


--
-- Name: ix_apscheduler_jobs_next_run_time; Type: INDEX; Schema: public; Owner: kashika
--

CREATE INDEX ix_apscheduler_jobs_next_run_time ON public.apscheduler_jobs USING btree (next_run_time);


--
-- Name: ix_completion_blocks_agent_execution_id; Type: INDEX; Schema: public; Owner: kashika
--

CREATE INDEX ix_completion_blocks_agent_execution_id ON public.completion_blocks USING btree (agent_execution_id);


--
-- Name: ix_completion_blocks_completion_id; Type: INDEX; Schema: public; Owner: kashika
--

CREATE INDEX ix_completion_blocks_completion_id ON public.completion_blocks USING btree (completion_id);


--
-- Name: ix_completion_blocks_id; Type: INDEX; Schema: public; Owner: kashika
--

CREATE INDEX ix_completion_blocks_id ON public.completion_blocks USING btree (id);


--
-- Name: ix_completion_feedbacks_id; Type: INDEX; Schema: public; Owner: kashika
--

CREATE UNIQUE INDEX ix_completion_feedbacks_id ON public.completion_feedbacks USING btree (id);


--
-- Name: ix_completions_id; Type: INDEX; Schema: public; Owner: kashika
--

CREATE UNIQUE INDEX ix_completions_id ON public.completions USING btree (id);


--
-- Name: ix_context_snapshots_agent_execution_id; Type: INDEX; Schema: public; Owner: kashika
--

CREATE INDEX ix_context_snapshots_agent_execution_id ON public.context_snapshots USING btree (agent_execution_id);


--
-- Name: ix_context_snapshots_id; Type: INDEX; Schema: public; Owner: kashika
--

CREATE UNIQUE INDEX ix_context_snapshots_id ON public.context_snapshots USING btree (id);


--
-- Name: ix_dashboard_layout_versions_id; Type: INDEX; Schema: public; Owner: kashika
--

CREATE UNIQUE INDEX ix_dashboard_layout_versions_id ON public.dashboard_layout_versions USING btree (id);


--
-- Name: ix_data_source_memberships_id; Type: INDEX; Schema: public; Owner: kashika
--

CREATE UNIQUE INDEX ix_data_source_memberships_id ON public.data_source_memberships USING btree (id);


--
-- Name: ix_data_sources_id; Type: INDEX; Schema: public; Owner: kashika
--

CREATE UNIQUE INDEX ix_data_sources_id ON public.data_sources USING btree (id);


--
-- Name: ix_datasource_tables_id; Type: INDEX; Schema: public; Owner: kashika
--

CREATE UNIQUE INDEX ix_datasource_tables_id ON public.datasource_tables USING btree (id);


--
-- Name: ix_entities_id; Type: INDEX; Schema: public; Owner: kashika
--

CREATE UNIQUE INDEX ix_entities_id ON public.entities USING btree (id);


--
-- Name: ix_entities_organization_id; Type: INDEX; Schema: public; Owner: kashika
--

CREATE INDEX ix_entities_organization_id ON public.entities USING btree (organization_id);


--
-- Name: ix_entities_owner_id; Type: INDEX; Schema: public; Owner: kashika
--

CREATE INDEX ix_entities_owner_id ON public.entities USING btree (owner_id);


--
-- Name: ix_external_platforms_id; Type: INDEX; Schema: public; Owner: kashika
--

CREATE UNIQUE INDEX ix_external_platforms_id ON public.external_platforms USING btree (id);


--
-- Name: ix_external_user_mappings_id; Type: INDEX; Schema: public; Owner: kashika
--

CREATE UNIQUE INDEX ix_external_user_mappings_id ON public.external_user_mappings USING btree (id);


--
-- Name: ix_feedback_org_report_ds_time; Type: INDEX; Schema: public; Owner: kashika
--

CREATE INDEX ix_feedback_org_report_ds_time ON public.table_feedback_events USING btree (org_id, report_id, data_source_id, created_at_event);


--
-- Name: ix_feedback_org_report_table_time; Type: INDEX; Schema: public; Owner: kashika
--

CREATE INDEX ix_feedback_org_report_table_time ON public.table_feedback_events USING btree (org_id, report_id, table_fqn, created_at_event);


--
-- Name: ix_feedback_table_time; Type: INDEX; Schema: public; Owner: kashika
--

CREATE INDEX ix_feedback_table_time ON public.table_feedback_events USING btree (table_fqn, created_at_event);


--
-- Name: ix_file_tags_id; Type: INDEX; Schema: public; Owner: kashika
--

CREATE UNIQUE INDEX ix_file_tags_id ON public.file_tags USING btree (id);


--
-- Name: ix_files_content_type; Type: INDEX; Schema: public; Owner: kashika
--

CREATE INDEX ix_files_content_type ON public.files USING btree (content_type);


--
-- Name: ix_files_filename; Type: INDEX; Schema: public; Owner: kashika
--

CREATE INDEX ix_files_filename ON public.files USING btree (filename);


--
-- Name: ix_files_id; Type: INDEX; Schema: public; Owner: kashika
--

CREATE UNIQUE INDEX ix_files_id ON public.files USING btree (id);


--
-- Name: ix_files_path; Type: INDEX; Schema: public; Owner: kashika
--

CREATE INDEX ix_files_path ON public.files USING btree (path);


--
-- Name: ix_git_repositories_id; Type: INDEX; Schema: public; Owner: kashika
--

CREATE UNIQUE INDEX ix_git_repositories_id ON public.git_repositories USING btree (id);


--
-- Name: ix_instruction_references_id; Type: INDEX; Schema: public; Owner: kashika
--

CREATE UNIQUE INDEX ix_instruction_references_id ON public.instruction_references USING btree (id);


--
-- Name: ix_instructions_id; Type: INDEX; Schema: public; Owner: kashika
--

CREATE UNIQUE INDEX ix_instructions_id ON public.instructions USING btree (id);


--
-- Name: ix_llm_models_id; Type: INDEX; Schema: public; Owner: kashika
--

CREATE UNIQUE INDEX ix_llm_models_id ON public.llm_models USING btree (id);


--
-- Name: ix_llm_providers_id; Type: INDEX; Schema: public; Owner: kashika
--

CREATE UNIQUE INDEX ix_llm_providers_id ON public.llm_providers USING btree (id);


--
-- Name: ix_memberships_id; Type: INDEX; Schema: public; Owner: kashika
--

CREATE UNIQUE INDEX ix_memberships_id ON public.memberships USING btree (id);


--
-- Name: ix_memories_id; Type: INDEX; Schema: public; Owner: kashika
--

CREATE UNIQUE INDEX ix_memories_id ON public.memories USING btree (id);


--
-- Name: ix_mentions_id; Type: INDEX; Schema: public; Owner: kashika
--

CREATE UNIQUE INDEX ix_mentions_id ON public.mentions USING btree (id);


--
-- Name: ix_metadata_indexing_jobs_id; Type: INDEX; Schema: public; Owner: kashika
--

CREATE UNIQUE INDEX ix_metadata_indexing_jobs_id ON public.metadata_indexing_jobs USING btree (id);


--
-- Name: ix_metadata_resources_id; Type: INDEX; Schema: public; Owner: kashika
--

CREATE UNIQUE INDEX ix_metadata_resources_id ON public.metadata_resources USING btree (id);


--
-- Name: ix_oauth_accounts_account_id; Type: INDEX; Schema: public; Owner: kashika
--

CREATE INDEX ix_oauth_accounts_account_id ON public.oauth_accounts USING btree (account_id);


--
-- Name: ix_oauth_accounts_oauth_name; Type: INDEX; Schema: public; Owner: kashika
--

CREATE INDEX ix_oauth_accounts_oauth_name ON public.oauth_accounts USING btree (oauth_name);


--
-- Name: ix_organization_settings_id; Type: INDEX; Schema: public; Owner: kashika
--

CREATE UNIQUE INDEX ix_organization_settings_id ON public.organization_settings USING btree (id);


--
-- Name: ix_organizations_id; Type: INDEX; Schema: public; Owner: kashika
--

CREATE UNIQUE INDEX ix_organizations_id ON public.organizations USING btree (id);


--
-- Name: ix_plan_decisions_agent_execution_id; Type: INDEX; Schema: public; Owner: kashika
--

CREATE INDEX ix_plan_decisions_agent_execution_id ON public.plan_decisions USING btree (agent_execution_id);


--
-- Name: ix_plan_decisions_id; Type: INDEX; Schema: public; Owner: kashika
--

CREATE UNIQUE INDEX ix_plan_decisions_id ON public.plan_decisions USING btree (id);


--
-- Name: ix_plans_id; Type: INDEX; Schema: public; Owner: kashika
--

CREATE UNIQUE INDEX ix_plans_id ON public.plans USING btree (id);


--
-- Name: ix_prompts_id; Type: INDEX; Schema: public; Owner: kashika
--

CREATE UNIQUE INDEX ix_prompts_id ON public.prompts USING btree (id);


--
-- Name: ix_queries_default_step_id; Type: INDEX; Schema: public; Owner: kashika
--

CREATE INDEX ix_queries_default_step_id ON public.queries USING btree (default_step_id);


--
-- Name: ix_queries_id; Type: INDEX; Schema: public; Owner: kashika
--

CREATE UNIQUE INDEX ix_queries_id ON public.queries USING btree (id);


--
-- Name: ix_queries_organization_id; Type: INDEX; Schema: public; Owner: kashika
--

CREATE INDEX ix_queries_organization_id ON public.queries USING btree (organization_id);


--
-- Name: ix_queries_report_id; Type: INDEX; Schema: public; Owner: kashika
--

CREATE INDEX ix_queries_report_id ON public.queries USING btree (report_id);


--
-- Name: ix_queries_user_id; Type: INDEX; Schema: public; Owner: kashika
--

CREATE INDEX ix_queries_user_id ON public.queries USING btree (user_id);


--
-- Name: ix_queries_widget_id; Type: INDEX; Schema: public; Owner: kashika
--

CREATE INDEX ix_queries_widget_id ON public.queries USING btree (widget_id);


--
-- Name: ix_reports_id; Type: INDEX; Schema: public; Owner: kashika
--

CREATE UNIQUE INDEX ix_reports_id ON public.reports USING btree (id);


--
-- Name: ix_reports_organization_id; Type: INDEX; Schema: public; Owner: kashika
--

CREATE INDEX ix_reports_organization_id ON public.reports USING btree (organization_id);


--
-- Name: ix_reports_slug; Type: INDEX; Schema: public; Owner: kashika
--

CREATE INDEX ix_reports_slug ON public.reports USING btree (slug);


--
-- Name: ix_reports_title; Type: INDEX; Schema: public; Owner: kashika
--

CREATE INDEX ix_reports_title ON public.reports USING btree (title);


--
-- Name: ix_reports_user_id; Type: INDEX; Schema: public; Owner: kashika
--

CREATE INDEX ix_reports_user_id ON public.reports USING btree (user_id);


--
-- Name: ix_sheet_schemas_id; Type: INDEX; Schema: public; Owner: kashika
--

CREATE UNIQUE INDEX ix_sheet_schemas_id ON public.sheet_schemas USING btree (id);


--
-- Name: ix_sheet_schemas_sheet_index; Type: INDEX; Schema: public; Owner: kashika
--

CREATE INDEX ix_sheet_schemas_sheet_index ON public.sheet_schemas USING btree (sheet_index);


--
-- Name: ix_sheet_schemas_sheet_name; Type: INDEX; Schema: public; Owner: kashika
--

CREATE INDEX ix_sheet_schemas_sheet_name ON public.sheet_schemas USING btree (sheet_name);


--
-- Name: ix_steps_query_id; Type: INDEX; Schema: public; Owner: kashika
--

CREATE INDEX ix_steps_query_id ON public.steps USING btree (query_id);


--
-- Name: ix_steps_slug; Type: INDEX; Schema: public; Owner: kashika
--

CREATE INDEX ix_steps_slug ON public.steps USING btree (slug);


--
-- Name: ix_steps_title; Type: INDEX; Schema: public; Owner: kashika
--

CREATE INDEX ix_steps_title ON public.steps USING btree (title);


--
-- Name: ix_table_feedback_events_id; Type: INDEX; Schema: public; Owner: kashika
--

CREATE UNIQUE INDEX ix_table_feedback_events_id ON public.table_feedback_events USING btree (id);


--
-- Name: ix_table_stats_id; Type: INDEX; Schema: public; Owner: kashika
--

CREATE UNIQUE INDEX ix_table_stats_id ON public.table_stats USING btree (id);


--
-- Name: ix_table_usage_events_id; Type: INDEX; Schema: public; Owner: kashika
--

CREATE UNIQUE INDEX ix_table_usage_events_id ON public.table_usage_events USING btree (id);


--
-- Name: ix_tabstats_dstbl; Type: INDEX; Schema: public; Owner: kashika
--

CREATE INDEX ix_tabstats_dstbl ON public.table_stats USING btree (datasource_table_id);


--
-- Name: ix_tabstats_org_report_ds_table; Type: INDEX; Schema: public; Owner: kashika
--

CREATE UNIQUE INDEX ix_tabstats_org_report_ds_table ON public.table_stats USING btree (org_id, report_id, data_source_id, table_fqn);


--
-- Name: ix_tabstats_table; Type: INDEX; Schema: public; Owner: kashika
--

CREATE INDEX ix_tabstats_table ON public.table_stats USING btree (table_fqn);


--
-- Name: ix_text_widgets_id; Type: INDEX; Schema: public; Owner: kashika
--

CREATE UNIQUE INDEX ix_text_widgets_id ON public.text_widgets USING btree (id);


--
-- Name: ix_tool_executions_agent_execution_id; Type: INDEX; Schema: public; Owner: kashika
--

CREATE INDEX ix_tool_executions_agent_execution_id ON public.tool_executions USING btree (agent_execution_id);


--
-- Name: ix_tool_executions_id; Type: INDEX; Schema: public; Owner: kashika
--

CREATE UNIQUE INDEX ix_tool_executions_id ON public.tool_executions USING btree (id);


--
-- Name: ix_usage_org_report_ds_time; Type: INDEX; Schema: public; Owner: kashika
--

CREATE INDEX ix_usage_org_report_ds_time ON public.table_usage_events USING btree (org_id, report_id, data_source_id, used_at);


--
-- Name: ix_usage_org_report_table_time; Type: INDEX; Schema: public; Owner: kashika
--

CREATE INDEX ix_usage_org_report_table_time ON public.table_usage_events USING btree (org_id, report_id, table_fqn, used_at);


--
-- Name: ix_usage_success; Type: INDEX; Schema: public; Owner: kashika
--

CREATE INDEX ix_usage_success ON public.table_usage_events USING btree (org_id, report_id, table_fqn, success, used_at);


--
-- Name: ix_usage_table_time; Type: INDEX; Schema: public; Owner: kashika
--

CREATE INDEX ix_usage_table_time ON public.table_usage_events USING btree (table_fqn, used_at);


--
-- Name: ix_user_data_source_columns_id; Type: INDEX; Schema: public; Owner: kashika
--

CREATE UNIQUE INDEX ix_user_data_source_columns_id ON public.user_data_source_columns USING btree (id);


--
-- Name: ix_user_data_source_columns_user_data_source_table_id; Type: INDEX; Schema: public; Owner: kashika
--

CREATE INDEX ix_user_data_source_columns_user_data_source_table_id ON public.user_data_source_columns USING btree (user_data_source_table_id);


--
-- Name: ix_user_data_source_credentials_data_source_id; Type: INDEX; Schema: public; Owner: kashika
--

CREATE INDEX ix_user_data_source_credentials_data_source_id ON public.user_data_source_credentials USING btree (data_source_id);


--
-- Name: ix_user_data_source_credentials_id; Type: INDEX; Schema: public; Owner: kashika
--

CREATE UNIQUE INDEX ix_user_data_source_credentials_id ON public.user_data_source_credentials USING btree (id);


--
-- Name: ix_user_data_source_credentials_organization_id; Type: INDEX; Schema: public; Owner: kashika
--

CREATE INDEX ix_user_data_source_credentials_organization_id ON public.user_data_source_credentials USING btree (organization_id);


--
-- Name: ix_user_data_source_credentials_user_id; Type: INDEX; Schema: public; Owner: kashika
--

CREATE INDEX ix_user_data_source_credentials_user_id ON public.user_data_source_credentials USING btree (user_id);


--
-- Name: ix_user_data_source_tables_data_source_id; Type: INDEX; Schema: public; Owner: kashika
--

CREATE INDEX ix_user_data_source_tables_data_source_id ON public.user_data_source_tables USING btree (data_source_id);


--
-- Name: ix_user_data_source_tables_id; Type: INDEX; Schema: public; Owner: kashika
--

CREATE UNIQUE INDEX ix_user_data_source_tables_id ON public.user_data_source_tables USING btree (id);


--
-- Name: ix_user_data_source_tables_user_id; Type: INDEX; Schema: public; Owner: kashika
--

CREATE INDEX ix_user_data_source_tables_user_id ON public.user_data_source_tables USING btree (user_id);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: kashika
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: ix_users_name; Type: INDEX; Schema: public; Owner: kashika
--

CREATE INDEX ix_users_name ON public.users USING btree (name);


--
-- Name: ix_visualizations_id; Type: INDEX; Schema: public; Owner: kashika
--

CREATE UNIQUE INDEX ix_visualizations_id ON public.visualizations USING btree (id);


--
-- Name: ix_visualizations_query_id; Type: INDEX; Schema: public; Owner: kashika
--

CREATE INDEX ix_visualizations_query_id ON public.visualizations USING btree (query_id);


--
-- Name: ix_visualizations_report_id; Type: INDEX; Schema: public; Owner: kashika
--

CREATE INDEX ix_visualizations_report_id ON public.visualizations USING btree (report_id);


--
-- Name: ix_widgets_slug; Type: INDEX; Schema: public; Owner: kashika
--

CREATE INDEX ix_widgets_slug ON public.widgets USING btree (slug);


--
-- Name: ix_widgets_title; Type: INDEX; Schema: public; Owner: kashika
--

CREATE INDEX ix_widgets_title ON public.widgets USING btree (title);


--
-- Name: agent_executions agent_executions_completion_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.agent_executions
    ADD CONSTRAINT agent_executions_completion_id_fkey FOREIGN KEY (completion_id) REFERENCES public.completions(id);


--
-- Name: agent_executions agent_executions_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.agent_executions
    ADD CONSTRAINT agent_executions_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: agent_executions agent_executions_report_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.agent_executions
    ADD CONSTRAINT agent_executions_report_id_fkey FOREIGN KEY (report_id) REFERENCES public.reports(id);


--
-- Name: agent_executions agent_executions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.agent_executions
    ADD CONSTRAINT agent_executions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: completion_blocks completion_blocks_agent_execution_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.completion_blocks
    ADD CONSTRAINT completion_blocks_agent_execution_id_fkey FOREIGN KEY (agent_execution_id) REFERENCES public.agent_executions(id);


--
-- Name: completion_blocks completion_blocks_completion_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.completion_blocks
    ADD CONSTRAINT completion_blocks_completion_id_fkey FOREIGN KEY (completion_id) REFERENCES public.completions(id);


--
-- Name: completion_blocks completion_blocks_plan_decision_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.completion_blocks
    ADD CONSTRAINT completion_blocks_plan_decision_id_fkey FOREIGN KEY (plan_decision_id) REFERENCES public.plan_decisions(id);


--
-- Name: completion_blocks completion_blocks_tool_execution_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.completion_blocks
    ADD CONSTRAINT completion_blocks_tool_execution_id_fkey FOREIGN KEY (tool_execution_id) REFERENCES public.tool_executions(id);


--
-- Name: completion_feedbacks completion_feedbacks_completion_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.completion_feedbacks
    ADD CONSTRAINT completion_feedbacks_completion_id_fkey FOREIGN KEY (completion_id) REFERENCES public.completions(id);


--
-- Name: completion_feedbacks completion_feedbacks_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.completion_feedbacks
    ADD CONSTRAINT completion_feedbacks_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: completion_feedbacks completion_feedbacks_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.completion_feedbacks
    ADD CONSTRAINT completion_feedbacks_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: completions completions_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.completions
    ADD CONSTRAINT completions_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.completions(id);


--
-- Name: completions completions_report_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.completions
    ADD CONSTRAINT completions_report_id_fkey FOREIGN KEY (report_id) REFERENCES public.reports(id);


--
-- Name: completions completions_step_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.completions
    ADD CONSTRAINT completions_step_id_fkey FOREIGN KEY (step_id) REFERENCES public.steps(id);


--
-- Name: completions completions_widget_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.completions
    ADD CONSTRAINT completions_widget_id_fkey FOREIGN KEY (widget_id) REFERENCES public.widgets(id);


--
-- Name: context_snapshots context_snapshots_agent_execution_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.context_snapshots
    ADD CONSTRAINT context_snapshots_agent_execution_id_fkey FOREIGN KEY (agent_execution_id) REFERENCES public.agent_executions(id);


--
-- Name: dashboard_layout_versions dashboard_layout_versions_report_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.dashboard_layout_versions
    ADD CONSTRAINT dashboard_layout_versions_report_id_fkey FOREIGN KEY (report_id) REFERENCES public.reports(id);


--
-- Name: data_source_memberships data_source_memberships_data_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.data_source_memberships
    ADD CONSTRAINT data_source_memberships_data_source_id_fkey FOREIGN KEY (data_source_id) REFERENCES public.data_sources(id);


--
-- Name: data_sources data_sources_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.data_sources
    ADD CONSTRAINT data_sources_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: datasource_tables datasource_tables_datasource_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.datasource_tables
    ADD CONSTRAINT datasource_tables_datasource_id_fkey FOREIGN KEY (datasource_id) REFERENCES public.data_sources(id);


--
-- Name: entities entities_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.entities
    ADD CONSTRAINT entities_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: entities entities_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.entities
    ADD CONSTRAINT entities_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id);


--
-- Name: entities entities_reviewed_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.entities
    ADD CONSTRAINT entities_reviewed_by_user_id_fkey FOREIGN KEY (reviewed_by_user_id) REFERENCES public.users(id);


--
-- Name: entities entities_source_step_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.entities
    ADD CONSTRAINT entities_source_step_id_fkey FOREIGN KEY (source_step_id) REFERENCES public.steps(id);


--
-- Name: entity_data_source_association entity_data_source_association_data_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.entity_data_source_association
    ADD CONSTRAINT entity_data_source_association_data_source_id_fkey FOREIGN KEY (data_source_id) REFERENCES public.data_sources(id);


--
-- Name: entity_data_source_association entity_data_source_association_entity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.entity_data_source_association
    ADD CONSTRAINT entity_data_source_association_entity_id_fkey FOREIGN KEY (entity_id) REFERENCES public.entities(id);


--
-- Name: external_platforms external_platforms_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.external_platforms
    ADD CONSTRAINT external_platforms_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: external_user_mappings external_user_mappings_app_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.external_user_mappings
    ADD CONSTRAINT external_user_mappings_app_user_id_fkey FOREIGN KEY (app_user_id) REFERENCES public.users(id);


--
-- Name: external_user_mappings external_user_mappings_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.external_user_mappings
    ADD CONSTRAINT external_user_mappings_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: file_tags file_tags_file_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.file_tags
    ADD CONSTRAINT file_tags_file_id_fkey FOREIGN KEY (file_id) REFERENCES public.files(id);


--
-- Name: completions fk_completions_user_id; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.completions
    ADD CONSTRAINT fk_completions_user_id FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: data_sources fk_data_sources_owner_user_id; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.data_sources
    ADD CONSTRAINT fk_data_sources_owner_user_id FOREIGN KEY (owner_user_id) REFERENCES public.users(id);


--
-- Name: files fk_files_organization_id; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.files
    ADD CONSTRAINT fk_files_organization_id FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: files fk_files_user_id; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.files
    ADD CONSTRAINT fk_files_user_id FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: instructions fk_instruction_agent_execution; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.instructions
    ADD CONSTRAINT fk_instruction_agent_execution FOREIGN KEY (agent_execution_id) REFERENCES public.agent_executions(id);


--
-- Name: instructions fk_instruction_reviewed_by; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.instructions
    ADD CONSTRAINT fk_instruction_reviewed_by FOREIGN KEY (reviewed_by_user_id) REFERENCES public.users(id);


--
-- Name: instructions fk_instruction_source; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.instructions
    ADD CONSTRAINT fk_instruction_source FOREIGN KEY (source_instruction_id) REFERENCES public.instructions(id);


--
-- Name: memberships fk_memberships_organization_id; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.memberships
    ADD CONSTRAINT fk_memberships_organization_id FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: memberships fk_memberships_user_id; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.memberships
    ADD CONSTRAINT fk_memberships_user_id FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: memories fk_memories_widget_id; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.memories
    ADD CONSTRAINT fk_memories_widget_id FOREIGN KEY (widget_id) REFERENCES public.widgets(id);


--
-- Name: reports fk_reports_external_platform_id; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.reports
    ADD CONSTRAINT fk_reports_external_platform_id FOREIGN KEY (external_platform_id) REFERENCES public.external_platforms(id);


--
-- Name: reports fk_reports_organization_id; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.reports
    ADD CONSTRAINT fk_reports_organization_id FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: reports fk_reports_user_id; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.reports
    ADD CONSTRAINT fk_reports_user_id FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: steps fk_steps_query_id_queries; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.steps
    ADD CONSTRAINT fk_steps_query_id_queries FOREIGN KEY (query_id) REFERENCES public.queries(id);


--
-- Name: steps fk_steps_widget_id; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.steps
    ADD CONSTRAINT fk_steps_widget_id FOREIGN KEY (widget_id) REFERENCES public.widgets(id);


--
-- Name: widgets fk_widgets_report_id; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.widgets
    ADD CONSTRAINT fk_widgets_report_id FOREIGN KEY (report_id) REFERENCES public.reports(id);


--
-- Name: git_repositories git_repositories_data_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.git_repositories
    ADD CONSTRAINT git_repositories_data_source_id_fkey FOREIGN KEY (data_source_id) REFERENCES public.data_sources(id);


--
-- Name: git_repositories git_repositories_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.git_repositories
    ADD CONSTRAINT git_repositories_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: git_repositories git_repositories_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.git_repositories
    ADD CONSTRAINT git_repositories_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: instruction_data_source_association instruction_data_source_association_data_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.instruction_data_source_association
    ADD CONSTRAINT instruction_data_source_association_data_source_id_fkey FOREIGN KEY (data_source_id) REFERENCES public.data_sources(id);


--
-- Name: instruction_data_source_association instruction_data_source_association_instruction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.instruction_data_source_association
    ADD CONSTRAINT instruction_data_source_association_instruction_id_fkey FOREIGN KEY (instruction_id) REFERENCES public.instructions(id);


--
-- Name: instruction_references instruction_references_instruction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.instruction_references
    ADD CONSTRAINT instruction_references_instruction_id_fkey FOREIGN KEY (instruction_id) REFERENCES public.instructions(id);


--
-- Name: instructions instructions_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.instructions
    ADD CONSTRAINT instructions_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: instructions instructions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.instructions
    ADD CONSTRAINT instructions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: llm_models llm_models_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.llm_models
    ADD CONSTRAINT llm_models_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: llm_models llm_models_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.llm_models
    ADD CONSTRAINT llm_models_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.llm_providers(id);


--
-- Name: llm_providers llm_providers_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.llm_providers
    ADD CONSTRAINT llm_providers_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: memories memories_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.memories
    ADD CONSTRAINT memories_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: memories memories_report_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.memories
    ADD CONSTRAINT memories_report_id_fkey FOREIGN KEY (report_id) REFERENCES public.reports(id);


--
-- Name: memories memories_step_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.memories
    ADD CONSTRAINT memories_step_id_fkey FOREIGN KEY (step_id) REFERENCES public.steps(id);


--
-- Name: memories memories_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.memories
    ADD CONSTRAINT memories_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: mentions mentions_completion_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.mentions
    ADD CONSTRAINT mentions_completion_id_fkey FOREIGN KEY (completion_id) REFERENCES public.completions(id);


--
-- Name: mentions mentions_report_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.mentions
    ADD CONSTRAINT mentions_report_id_fkey FOREIGN KEY (report_id) REFERENCES public.reports(id);


--
-- Name: metadata_indexing_jobs metadata_indexing_jobs_data_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.metadata_indexing_jobs
    ADD CONSTRAINT metadata_indexing_jobs_data_source_id_fkey FOREIGN KEY (data_source_id) REFERENCES public.data_sources(id);


--
-- Name: metadata_indexing_jobs metadata_indexing_jobs_git_repository_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.metadata_indexing_jobs
    ADD CONSTRAINT metadata_indexing_jobs_git_repository_id_fkey FOREIGN KEY (git_repository_id) REFERENCES public.git_repositories(id);


--
-- Name: metadata_indexing_jobs metadata_indexing_jobs_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.metadata_indexing_jobs
    ADD CONSTRAINT metadata_indexing_jobs_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: metadata_resources metadata_resources_data_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.metadata_resources
    ADD CONSTRAINT metadata_resources_data_source_id_fkey FOREIGN KEY (data_source_id) REFERENCES public.data_sources(id);


--
-- Name: metadata_resources metadata_resources_metadata_indexing_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.metadata_resources
    ADD CONSTRAINT metadata_resources_metadata_indexing_job_id_fkey FOREIGN KEY (metadata_indexing_job_id) REFERENCES public.metadata_indexing_jobs(id);


--
-- Name: oauth_accounts oauth_accounts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.oauth_accounts
    ADD CONSTRAINT oauth_accounts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: organization_settings organization_settings_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.organization_settings
    ADD CONSTRAINT organization_settings_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: plan_decisions plan_decisions_agent_execution_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.plan_decisions
    ADD CONSTRAINT plan_decisions_agent_execution_id_fkey FOREIGN KEY (agent_execution_id) REFERENCES public.agent_executions(id);


--
-- Name: plan_decisions plan_decisions_context_snapshot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.plan_decisions
    ADD CONSTRAINT plan_decisions_context_snapshot_id_fkey FOREIGN KEY (context_snapshot_id) REFERENCES public.context_snapshots(id);


--
-- Name: plans plans_completion_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.plans
    ADD CONSTRAINT plans_completion_id_fkey FOREIGN KEY (completion_id) REFERENCES public.completions(id);


--
-- Name: plans plans_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.plans
    ADD CONSTRAINT plans_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: plans plans_report_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.plans
    ADD CONSTRAINT plans_report_id_fkey FOREIGN KEY (report_id) REFERENCES public.reports(id);


--
-- Name: plans plans_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.plans
    ADD CONSTRAINT plans_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: prompts prompts_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.prompts
    ADD CONSTRAINT prompts_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: prompts prompts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.prompts
    ADD CONSTRAINT prompts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: queries queries_default_step_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.queries
    ADD CONSTRAINT queries_default_step_id_fkey FOREIGN KEY (default_step_id) REFERENCES public.steps(id);


--
-- Name: queries queries_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.queries
    ADD CONSTRAINT queries_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: queries queries_report_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.queries
    ADD CONSTRAINT queries_report_id_fkey FOREIGN KEY (report_id) REFERENCES public.reports(id);


--
-- Name: queries queries_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.queries
    ADD CONSTRAINT queries_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: queries queries_widget_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.queries
    ADD CONSTRAINT queries_widget_id_fkey FOREIGN KEY (widget_id) REFERENCES public.widgets(id);


--
-- Name: report_data_source_association report_data_source_association_data_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.report_data_source_association
    ADD CONSTRAINT report_data_source_association_data_source_id_fkey FOREIGN KEY (data_source_id) REFERENCES public.data_sources(id);


--
-- Name: report_data_source_association report_data_source_association_report_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.report_data_source_association
    ADD CONSTRAINT report_data_source_association_report_id_fkey FOREIGN KEY (report_id) REFERENCES public.reports(id);


--
-- Name: report_file_association report_file_association_file_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.report_file_association
    ADD CONSTRAINT report_file_association_file_id_fkey FOREIGN KEY (file_id) REFERENCES public.files(id) ON DELETE CASCADE;


--
-- Name: report_file_association report_file_association_report_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.report_file_association
    ADD CONSTRAINT report_file_association_report_id_fkey FOREIGN KEY (report_id) REFERENCES public.reports(id) ON DELETE CASCADE;


--
-- Name: sheet_schemas sheet_schemas_file_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.sheet_schemas
    ADD CONSTRAINT sheet_schemas_file_id_fkey FOREIGN KEY (file_id) REFERENCES public.files(id);


--
-- Name: table_feedback_events table_feedback_events_completion_feedback_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.table_feedback_events
    ADD CONSTRAINT table_feedback_events_completion_feedback_id_fkey FOREIGN KEY (completion_feedback_id) REFERENCES public.completion_feedbacks(id);


--
-- Name: table_feedback_events table_feedback_events_data_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.table_feedback_events
    ADD CONSTRAINT table_feedback_events_data_source_id_fkey FOREIGN KEY (data_source_id) REFERENCES public.data_sources(id);


--
-- Name: table_feedback_events table_feedback_events_datasource_table_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.table_feedback_events
    ADD CONSTRAINT table_feedback_events_datasource_table_id_fkey FOREIGN KEY (datasource_table_id) REFERENCES public.datasource_tables(id);


--
-- Name: table_feedback_events table_feedback_events_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.table_feedback_events
    ADD CONSTRAINT table_feedback_events_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: table_feedback_events table_feedback_events_report_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.table_feedback_events
    ADD CONSTRAINT table_feedback_events_report_id_fkey FOREIGN KEY (report_id) REFERENCES public.reports(id);


--
-- Name: table_feedback_events table_feedback_events_step_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.table_feedback_events
    ADD CONSTRAINT table_feedback_events_step_id_fkey FOREIGN KEY (step_id) REFERENCES public.steps(id);


--
-- Name: table_stats table_stats_data_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.table_stats
    ADD CONSTRAINT table_stats_data_source_id_fkey FOREIGN KEY (data_source_id) REFERENCES public.data_sources(id);


--
-- Name: table_stats table_stats_datasource_table_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.table_stats
    ADD CONSTRAINT table_stats_datasource_table_id_fkey FOREIGN KEY (datasource_table_id) REFERENCES public.datasource_tables(id);


--
-- Name: table_stats table_stats_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.table_stats
    ADD CONSTRAINT table_stats_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: table_stats table_stats_report_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.table_stats
    ADD CONSTRAINT table_stats_report_id_fkey FOREIGN KEY (report_id) REFERENCES public.reports(id);


--
-- Name: table_usage_events table_usage_events_data_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.table_usage_events
    ADD CONSTRAINT table_usage_events_data_source_id_fkey FOREIGN KEY (data_source_id) REFERENCES public.data_sources(id);


--
-- Name: table_usage_events table_usage_events_datasource_table_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.table_usage_events
    ADD CONSTRAINT table_usage_events_datasource_table_id_fkey FOREIGN KEY (datasource_table_id) REFERENCES public.datasource_tables(id);


--
-- Name: table_usage_events table_usage_events_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.table_usage_events
    ADD CONSTRAINT table_usage_events_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: table_usage_events table_usage_events_report_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.table_usage_events
    ADD CONSTRAINT table_usage_events_report_id_fkey FOREIGN KEY (report_id) REFERENCES public.reports(id);


--
-- Name: table_usage_events table_usage_events_step_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.table_usage_events
    ADD CONSTRAINT table_usage_events_step_id_fkey FOREIGN KEY (step_id) REFERENCES public.steps(id);


--
-- Name: table_usage_events table_usage_events_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.table_usage_events
    ADD CONSTRAINT table_usage_events_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: text_widgets text_widgets_report_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.text_widgets
    ADD CONSTRAINT text_widgets_report_id_fkey FOREIGN KEY (report_id) REFERENCES public.reports(id);


--
-- Name: tool_executions tool_executions_agent_execution_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.tool_executions
    ADD CONSTRAINT tool_executions_agent_execution_id_fkey FOREIGN KEY (agent_execution_id) REFERENCES public.agent_executions(id);


--
-- Name: tool_executions tool_executions_context_snapshot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.tool_executions
    ADD CONSTRAINT tool_executions_context_snapshot_id_fkey FOREIGN KEY (context_snapshot_id) REFERENCES public.context_snapshots(id);


--
-- Name: tool_executions tool_executions_created_step_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.tool_executions
    ADD CONSTRAINT tool_executions_created_step_id_fkey FOREIGN KEY (created_step_id) REFERENCES public.steps(id);


--
-- Name: tool_executions tool_executions_created_widget_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.tool_executions
    ADD CONSTRAINT tool_executions_created_widget_id_fkey FOREIGN KEY (created_widget_id) REFERENCES public.widgets(id);


--
-- Name: tool_executions tool_executions_plan_decision_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.tool_executions
    ADD CONSTRAINT tool_executions_plan_decision_id_fkey FOREIGN KEY (plan_decision_id) REFERENCES public.plan_decisions(id);


--
-- Name: user_data_source_columns user_data_source_columns_user_data_source_table_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.user_data_source_columns
    ADD CONSTRAINT user_data_source_columns_user_data_source_table_id_fkey FOREIGN KEY (user_data_source_table_id) REFERENCES public.user_data_source_tables(id);


--
-- Name: user_data_source_credentials user_data_source_credentials_data_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.user_data_source_credentials
    ADD CONSTRAINT user_data_source_credentials_data_source_id_fkey FOREIGN KEY (data_source_id) REFERENCES public.data_sources(id);


--
-- Name: user_data_source_credentials user_data_source_credentials_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.user_data_source_credentials
    ADD CONSTRAINT user_data_source_credentials_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: user_data_source_credentials user_data_source_credentials_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.user_data_source_credentials
    ADD CONSTRAINT user_data_source_credentials_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: user_data_source_tables user_data_source_tables_data_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.user_data_source_tables
    ADD CONSTRAINT user_data_source_tables_data_source_id_fkey FOREIGN KEY (data_source_id) REFERENCES public.data_sources(id);


--
-- Name: user_data_source_tables user_data_source_tables_data_source_table_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.user_data_source_tables
    ADD CONSTRAINT user_data_source_tables_data_source_table_id_fkey FOREIGN KEY (data_source_table_id) REFERENCES public.datasource_tables(id);


--
-- Name: user_data_source_tables user_data_source_tables_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.user_data_source_tables
    ADD CONSTRAINT user_data_source_tables_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: visualizations visualizations_query_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.visualizations
    ADD CONSTRAINT visualizations_query_id_fkey FOREIGN KEY (query_id) REFERENCES public.queries(id);


--
-- Name: visualizations visualizations_report_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kashika
--

ALTER TABLE ONLY public.visualizations
    ADD CONSTRAINT visualizations_report_id_fkey FOREIGN KEY (report_id) REFERENCES public.reports(id);


--
-- PostgreSQL database dump complete
--

\unrestrict Vy7a4tpt31ZN35ehoau0VBMCWySl8faWBuFRNIox1P1v2Bw3qv1hueqg0qKPeoA

